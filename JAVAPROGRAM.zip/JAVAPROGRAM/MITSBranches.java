import java.util.Scanner;

public class MITSBranches {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("MITS COLLEGE - BRANCH CODES");
        System.out.print("Enter Branch Code: ");

        String code = sc.nextLine().toUpperCase();

        switch (code) {

            case "CSE":
                System.out.println("Computer Science and Engineering");
                break;

            case "ECE":
                System.out.println("Electronics and Communication Engineering");
                break;

            case "CSD":
                System.out.println("Computer Science and Engineering (Data Science)");
                break;

            case "CSM":
                System.out.println("Computer Science and Engineering (AI & ML)");
                break;

            case "EEE":
                System.out.println("Electrical and Electronics Engineering");
                break;

            case "ME":
                System.out.println("Mechanical Engineering");
                break;

            case "CIV":
                System.out.println("Civil Engineering");
                break;

            case "IT":
                System.out.println("Information Technology");
                break;

            case "AIM":
                System.out.println("Artificial Intelligence and Machine Learning");
                break;

            case "CSC":
                System.out.println("Computer Science and Cyber Security");
                break;

            default:
                System.out.println("Invalid Branch Code");
        }

        sc.close();
    }
}