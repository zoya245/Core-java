import java.util.Scanner;
class datatypes3{
    public static void main (String args[]){
        Scanner obj = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int a=obj.nextInt();
        if(a<=10){
             System.out.println("Condition is true");
            
        }
    }
}