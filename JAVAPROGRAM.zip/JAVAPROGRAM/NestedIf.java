import java.util.Scanner;

public class NestedIf {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = sc.nextInt();
        if (num > 0) {
            System.out.println("Positive Number");
            if (num % 2 == 0) {
                System.out.println("Even Number");
            }
        }
        sc.close();
    }
}