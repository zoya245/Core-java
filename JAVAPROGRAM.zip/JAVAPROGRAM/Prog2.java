import java.util.Scanner;
class Prog2{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter byte value: ");
        byte a = sc.nextByte();
        System.out.print("Enter short value: ");
        short b = sc.nextShort();
        System.out.print("Enter int value: ");
        int c = sc.nextInt();
        System.out.print("Enter long value: ");
        long d = sc.nextLong();
        System.out.print("Enter float value: ");
        float e = sc.nextFloat();
        System.out.print("Enter double value: ");
        double f = sc.nextDouble();
        System.out.print("Enter character: ");
        char g = sc.next().charAt(0);
        System.out.print("Enter boolean value: ");
        boolean h = sc.nextBoolean();

        System.out.println("Byte value: " + a);
        System.out.println("Short value: " + b);
        System.out.println("Int value: " + c);
        System.out.println("Long value: " + d);
        System.out.println("Float value: " + e);
        System.out.println("Double value: " + f);
        System.out.println("Character: " + g);
        System.out.println("Boolean: " + h);

        sc.close();
    }
}

