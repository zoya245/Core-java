import java.util.Scanner;
class Operators{

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter petty cash: ");
        int pettycash = sc.nextInt();

        System.out.print("Enter tiffin expense: ");
        int tiffin = sc.nextInt();

        System.out.print("Enter dinner expense: ");
        int dinner = sc.nextInt();

        int total_expenses = pettycash + tiffin + dinner;

        System.out.println("Total Expenses: " + total_expenses);

        System.out.print("Enter number of days: ");
        int days = sc.nextInt();

        float avg_per_day = (float) total_expenses / days;

        System.out.println("Average Expense Per Day: " + avg_per_day);

        sc.close();
    }
}