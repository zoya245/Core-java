import java.util.Scanner;

public class datatypes {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int num = obj.nextInt();
        int lachi = obj.nextInt();
        System.out.println("The number is: " + (num&lachi));
        System.out.println("The number is: " + (num|lachi));
        System.out.println("The number is: " + (num^lachi));
        System.out.println("The number is: " + (~num));
        System.out.println("The number is: " + (num<<lachi));
        System.out.println("The number is: " + (num>>lachi));
        System.out.println("The number is: " + (num>>lachi));
    }
}